// NE ZABORAVI EXPORTATI NA DNU 

const data = {
    "types": [ 
        {
            "typeName": 'Outdoors',
            "noOfSubs": 0, 
            "photo": '/images/Outdoors.jpg' 
        }, 
        {
            "typeName": 'Sports',
            "noOfSubs": 0, 
            "photo": '/images/Sports.jpg' 
        }, 
        {
            "typeName": 'Pizzas',
            "noOfSubs": 0, 
            "photo": '/images/Pizzas.jpg' 
        }, 
        {
            "typeName": 'Woks',
            "noOfSubs": 0, 
            "photo": '/images/Woks.jpg' 
        }, 
        {
            "typeName": 'Politics',
            "noOfSubs": 0, 
            "photo": '/images/Politics.jpg' 
        }, 
        {
            "typeName": 'Technology',
            "noOfSubs": 0, 
            "photo": '/images/Technology.jpg' 
        }, 
        {
            "typeName": 'Pets',
            "noOfSubs": 0, 
            "photo": '/images/Pets.jpg' 
        }, 
        {
            "typeName": 'BBQ',
            "noOfSubs": 0, 
            "photo": '/images/BBQ.jpg' 
        }, 
    ]
};

module.exports = data; // OVO NI SLUCAJNO NE ZABORAVI 