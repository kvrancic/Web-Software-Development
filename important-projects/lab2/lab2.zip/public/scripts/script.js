let cartValue = Number(document.getElementById('cart-amount').innerHTML);
